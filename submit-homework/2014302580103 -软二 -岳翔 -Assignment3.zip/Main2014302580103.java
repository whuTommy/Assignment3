
public class Main2014302580103 {
	public static void main(String args[]) throws Exception {
		SingleThread singleThread=new SingleThread();
		MultipleThreadOperation multipleThreadOperation =new MultipleThreadOperation();
		
	}
}
