
// ������
class Consumer implements Runnable {

	StoreHouse storeHouse;

	public Consumer(StoreHouse storeHouse) {
		// TODO Auto-generated constructor stub
		this.storeHouse = storeHouse;
	}

	@Override
	public void run() {
		try {
			storeHouse.informationOperation();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}