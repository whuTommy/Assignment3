import java.io.File;
import java.io.IOException;
import java.util.Vector;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class HomePageCrawler {

	public String linksArray[];// �ӽ��������
	private String fileNameString;//������

	public HomePageCrawler() throws IOException
	{
		fileNameString="TeacherIndexHtml.html";
		elementsSelect();
	}
	public void htmlCrawler() {

		// ��ȡ��ʦ��ҳ��ʹ��HttpRequest��
		HttpRequest respond = HttpRequest
				.get("http://staff.whu.edu.cn/?key=&title=0&showhomepage=0&college=%E8%AE%A1%E7%AE%97%E6%9C%BA%E5%AD%A6%E9%99%A2&cid=211&lang=cn");
		if (respond.ok()) {
			fileNameString = "TeacherIndexHtml.html";
			respond.receive(new File(fileNameString));
		}
	}

	public void elementsSelect() throws IOException {

		// ʹ��Jsoup����HTML
		htmlCrawler();
		
		File input=new File(fileNameString);
		
		Document doc = Jsoup.parse(input, "UTF-8");
		Elements links = doc.getElementsByTag("a");
		int arrayNum = links.size();
		String linkArray[] = new String[arrayNum];
		int iCount = 0;
		for (Element link : links) {
			String linkHref = link.attr("href");
			linkArray[iCount] = linkHref;
			// System.out.println(linkArray[iCount]);
			iCount++;
		}
		linkOperation(linkArray);
		// System.out.println(text);
	}

	// ����ȡ��������������в���
	public void linkOperation(String[] arr) {
		Vector<String> vector = new Vector<String>();
		for (int i = 0; i < arr.length; i++) {
			char buf[] = arr[i].toCharArray();
			if (buf[0] == 's') {
				vector.add(arr[i]);
			}
		}
		int arrSize = vector.size();
		linksArray = new String[arrSize];
		for (int j = 0; j < arrSize; j++) {
			linksArray[j] = vector.elementAt(j);
			String str=linksArray[j].replace(" ", "%20");
			linksArray[j]="http://staff.whu.edu.cn/" + str;
			

			//System.out.println(linksArray[j]);
		}
	}
}
