import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class DataBaseOperation {
	
	private String text;// ��ϸ��Ϣ
	private String teacherName;// ��ʦ����
	private String telNum;// �绰����
	private String emailAddres;// ����
	private int linkArrayNum;//���������С
	
	private SubPageCrawler subPageCrawler;
	
	//�������ݿ���ز���
	public static final String DBDRIVER="com.mysql.jdbc.Driver";//���ݿ�����
	public static final String DBURL="jdbc:mysql://localhost:3306/whu_cs_teacherinformation";//��ַ
	public static final String DBUSER="root";//�˻���
	public static final String DBPASS="0901";//����
	
	public DataBaseOperation() throws IOException
	{
		subPageCrawler=new SubPageCrawler();
		subPageCrawler.OperationAll();
		linkArrayNum=subPageCrawler.getLinkArrayNum();
	}
	
	public void getInformation(int index)//��ȡ��Ϣ
	{
		text=subPageCrawler.getTextArrayString(index);
		teacherName=subPageCrawler.getTeacherNameArrayString(index);
		telNum=subPageCrawler.getTelNumArrayString(index);
		emailAddres=subPageCrawler.getEmailAddressArrayString(index);
	}
	
	public void ClearAll() {
		teacherName = "";
		telNum = "";
		emailAddres = "";
		text = "";
	}
	
	public void DB_Operate() throws Exception
	{
		Connection connection=null;
		PreparedStatement pstmt=null;
		String sql="INSERT INTO teacherInfomation(name,tel,email,text)VALUES(?,?,?,?)";
		Class.forName(DBDRIVER);//������������
		connection=DriverManager.getConnection(DBURL,DBUSER,DBPASS);//�������ݿ�
		pstmt=connection.prepareStatement(sql);
		for (int i = 0; i < linkArrayNum; i++)
		{
			getInformation(i);
			pstmt.setString(1, teacherName);
			pstmt.setString(2, telNum);
			pstmt.setString(3, emailAddres);
			pstmt.setString(4, text);
			pstmt.executeUpdate();
			ClearAll();
		}
		pstmt.close();
		connection.close();
	}
	
}
