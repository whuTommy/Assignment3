import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class SubPageCrawler {

	private String text;// ��ϸ��Ϣ
	private String teacherName;// ��ʦ����
	private String telNum;// �绰����
	private String emailAddres;// ����

	private HomePageCrawler homePageCrawler;

	private int linkArrayNum;
	private String teacherNameArray[];// ��ʦ��������
	private String telNumArray[];// �绰��������
	private String emailAddressArray[];// ��������
	private String textArray[];// ��ϸ��Ϣ����

	public int getLinkArrayNum()
	{
		return linkArrayNum;
	}

	public SubPageCrawler() throws IOException {
		homePageCrawler = new HomePageCrawler();
		linkArrayNum = homePageCrawler.linksArray.length;
		teacherNameArray = new String[linkArrayNum];
		telNumArray = new String[linkArrayNum];
		emailAddressArray = new String[linkArrayNum];
		textArray = new String[linkArrayNum];
	}

	public void subHtmlCrawler() {

		for (int i = 0; i < linkArrayNum; i++)
		// ��ȡ��ʦ��ҳ��ʹ��HttpRequest��
		{
			String linksString = homePageCrawler.linksArray[i];
			HttpRequest respond = HttpRequest.get(linksString);
			if (respond.ok()) {
				String fileNameString = "TeacherHtml" + i + ".html";
				respond.receive(new File(fileNameString));
			}
		}
	}

	public void elementsSelect2(File input) throws IOException {

		// ʹ��Jsoup����HTML

		Document doc = Jsoup.parse(input, "UTF-8");
		Elements p_Tag = doc.select("p");
		Elements h3_tag = doc.select("h3");
		teacherName = h3_tag.get(0).text();
		text = p_Tag.get(0).text();

		// System.out.println(teacherName + "  " + text);
	}

	public void regularExpression() {

		// ʹ���������ʽ��ȡ�����Ϣ

		// ƥ��绰

		String regex1 = "\\d*";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(text);
		while (m1.find()) {
			if (!"".equals(m1.group())) {
				telNum = m1.group();
			}
		}
		// System.out.println(telNum);

		// ƥ������

		String regex2 = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(text);
		while (m2.find()) {
			emailAddres = m2.group();
		}
		// System.out.println(emailAddres);
	}

	

	public void arrayOperation(int index) {
		teacherNameArray[index] = teacherName;
		telNumArray[index] = telNum;
		emailAddressArray[index] = emailAddres;
		textArray[index] = text;
	}

	public void textClear() {
		teacherName = "";
		telNum = "";
		emailAddres = "";
		text = "";
	}

	public void OperationAll() throws IOException {
		subHtmlCrawler();// ������ȡ����ҳ����
		for (int i = 0; i < linkArrayNum; i++) {
			File inputHtmlFile = new File("TeacherHtml" + i + ".html");// ��ȡ·��
			elementsSelect2(inputHtmlFile);// ����jsoup��������
			regularExpression();// �����������ʽ��ȡ����
			arrayOperation(i);
			textClear();
		}
	}
	
	public String getTeacherNameArrayString(int index) {

		return teacherNameArray[index];
	}

	public String getTelNumArrayString(int index) {

		return telNumArray[index];
	}

	public String getEmailAddressArrayString(int index) {

		return emailAddressArray[index];
	}

	public String getTextArrayString(int index) {

		return textArray[index];
	}

}
