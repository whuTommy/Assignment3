
public class MultipleThreadOperation {
	
	public MultipleThreadOperation() throws Exception
	{
		StoreHouse storeHouse = new StoreHouse();
		Producer producer=new Producer(storeHouse);
		Consumer consumer=new Consumer(storeHouse);
		
		Thread t1=new Thread(consumer);
		Thread t2=new Thread(producer);
	
		t1.start();
		t2.start();
		
	}

	

}
