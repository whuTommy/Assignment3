import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;


class StoreHouse// �ֿ�
{
	private HomePageCrawler homePageCrawler;// ��ȡ����ҳ
	public static int linkArrayNum;// ���������Ԫ�ظ���

	private String text;// ��ϸ��Ϣ
	private String teacherName;// ��ʦ����
	private String telNum;// �绰����
	private String emailAddres;// ����

	public static final String DBDRIVER = "com.mysql.jdbc.Driver";// ���ݿ�����
	public static final String DBURL = "jdbc:mysql://localhost:3306/whu_cs_teacherinformation";// ��ַ
	public static final String DBUSER = "root";// �˻���
	public static final String DBPASS = "0901";// ����

	public Connection connection = null;
	public PreparedStatement pstmt = null;

	private boolean flag = false;

	public StoreHouse() throws IOException {
		homePageCrawler = new HomePageCrawler();
		linkArrayNum = homePageCrawler.linksArray.length;
	}

	public synchronized void subPageCrawler() {
		if (flag) {
			try {

				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for (int i = 0; i < linkArrayNum; i++)
		// ��ȡ��ʦ��ҳ��ʹ��HttpRequest��
		{
			String linksString = homePageCrawler.linksArray[i];
			HttpRequest respond = HttpRequest.get(linksString);
			if (respond.ok()) {
				String fileNameString = "TeacherHtml" + i + ".html";
				respond.receive(new File(fileNameString));
			}
		}
		flag = true;
		this.notify();// ����
	}

	public void elementsSelect2(File input) throws IOException {

		// ʹ��Jsoup����HTML

		Document doc = Jsoup.parse(input, "UTF-8");
		Elements p_Tag = doc.select("p");
		Elements h3_tag = doc.select("h3");
		teacherName = h3_tag.get(0).text();
		text = p_Tag.get(0).text();

		// System.out.println(teacherName + "  " + text);
	}

	public void regularExpression() {

		// ʹ���������ʽ��ȡ�����Ϣ

		// ƥ��绰

		String regex1 = "\\d*";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(text);
		while (m1.find()) {
			if (!"".equals(m1.group())) {
				telNum = m1.group();
			}
		}
		// System.out.println(telNum);

		// ƥ������

		String regex2 = "[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(text);
		while (m2.find()) {
			emailAddres = m2.group();
		}
		// System.out.println(emailAddres);
	}

	public void textClear() {
		teacherName = "";
		telNum = "";
		emailAddres = "";
		text = "";
	}

	public void DB_Connect() throws Exception {
		Class.forName(DBDRIVER);// ������������
		connection = DriverManager.getConnection(DBURL, DBUSER, DBPASS);// �������ݿ�
		String sql = "INSERT INTO teacherInfomation(name,tel,email,text)VALUES(?,?,?,?)";
		pstmt = connection.prepareStatement(sql);
	}

	public void DB_Disconnect() throws Exception {
		pstmt.close();
		connection.close();
	}

	public void DB_Operate() throws Exception {
		pstmt.setString(1, teacherName);
		pstmt.setString(2, telNum);
		pstmt.setString(3, emailAddres);
		pstmt.setString(4, text);
		pstmt.executeUpdate();
	}

	public synchronized void informationOperation() throws Exception {
		long startTime=System.currentTimeMillis();   //��ȡ��ʼʱ��
		if (!flag) {
			try {
				this.wait();
			} catch (InterruptedException e) {
			}
		}

		DB_Connect();

		for (int i = 0; i < linkArrayNum; i++) {
			File inputHtmlFile = new File("TeacherHtml" + i + ".html");
			elementsSelect2(inputHtmlFile);// ����jsoup��������
			regularExpression();// �����������ʽ��ȡ��
			DB_Operate();
			textClear();
		}

		DB_Disconnect();

		flag = false;
		notify();
		long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
		System.out.println("���߳�����ʱ�䣺 "+(endTime-startTime)+"ms");
	}
	
}
